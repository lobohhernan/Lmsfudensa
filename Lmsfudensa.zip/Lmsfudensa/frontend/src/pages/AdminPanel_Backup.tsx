// Este archivo es el backup del AdminPanel antiguo con datos estáticos
// Se mantiene solo como referencia
// El nuevo AdminPanel está en AdminPanel.tsx
