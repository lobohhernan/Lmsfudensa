
  # LMS Prototipo FUDENSA

  This is a code bundle for LMS Prototipo FUDENSA. The original project is available at https://www.figma.com/design/w3DuUV7ltcerZrOFVGGafw/LMS-Prototipo-FUDENSA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  